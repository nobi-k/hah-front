import React from 'react';
import Card from '../ui/Card';

interface AutoApplyControlProps {
  isApplying: boolean;
  onToggle: () => void;
  isDisabled: boolean;
  onDisabledClick: () => void;
}

const PlayIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

const StopIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

const AutoApplyControl: React.FC<AutoApplyControlProps> = ({ isApplying, onToggle, isDisabled, onDisabledClick }) => {
  const handleClick = () => {
    if (isDisabled) {
      onDisabledClick();
    } else {
      onToggle();
    }
  };
  
  return (
    <Card title="Управление автооткликами" className="text-center">
      <div className="space-y-4">
        <button
          onClick={handleClick}
          aria-disabled={isDisabled}
          className={`w-full flex items-center justify-center py-4 px-6 border border-transparent rounded-md shadow-lg text-lg font-bold text-white transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800
            ${isDisabled ? 'bg-gray-600 cursor-not-allowed' :
              isApplying ? 'bg-red-600 hover:bg-red-700 focus:ring-red-500' :
              'bg-green-600 hover:bg-green-700 focus:ring-green-500'}`
          }
        >
          {isApplying ? <StopIcon /> : <PlayIcon />}
          <span className="ml-3">{isApplying ? 'Остановить' : 'Запустить'}</span>
        </button>
        <p className={`text-sm ${isApplying ? 'text-green-400 animate-pulse' : 'text-gray-400'}`}>
          {isDisabled ? 'Выберите хотя бы одно резюме' : isApplying ? 'Процесс запущен...' : 'Система готова к запуску'}
        </p>
      </div>
    </Card>
  );
};

export default AutoApplyControl;