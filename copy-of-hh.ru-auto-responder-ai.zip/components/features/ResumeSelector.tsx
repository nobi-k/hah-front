import React from 'react';
import Card from '../ui/Card';
import { Resume } from '../../types';

interface ResumeSelectorProps {
  resumes: Resume[];
  selectedIds: string[];
  onSelectionChange: (ids: string[]) => void;
}

const FileTextIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
);

const PencilIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" />
    </svg>
);


const ResumeSelector: React.FC<ResumeSelectorProps> = ({ resumes, selectedIds, onSelectionChange }) => {
  const handleToggle = (id: string) => {
    const newSelectedIds = selectedIds.includes(id)
      ? selectedIds.filter(selectedId => selectedId !== id)
      : [...selectedIds, id];
    onSelectionChange(newSelectedIds);
  };

  return (
    <Card title="Выберите резюме" icon={<FileTextIcon />}>
      <div className="space-y-4">
        {resumes.map(resume => (
          <div
            key={resume.id}
            onClick={() => handleToggle(resume.id)}
            className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-all duration-200 ${
              selectedIds.includes(resume.id)
                ? 'bg-primary-900/50 border border-primary-600'
                : 'bg-gray-700/50 hover:bg-gray-700'
            }`}
          >
            <div className="flex items-center">
                <input
                  type="checkbox"
                  readOnly
                  checked={selectedIds.includes(resume.id)}
                  className="h-5 w-5 rounded text-primary-600 bg-gray-900 border-gray-600 focus:ring-primary-500 cursor-pointer"
                />
                <div className="ml-4">
                  <p className="font-medium text-white">{resume.title}</p>
                  <p className="text-sm text-gray-400">Обновлено: {new Date(resume.updatedAt).toLocaleDateString('ru-RU')}</p>
                </div>
            </div>
             <a
              href={`https://hh.ru/resume/${resume.id}?custom_edit=true`} // Mock link to hh.ru edit page
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()} // Prevent card click from triggering
              className="p-2 rounded-full text-gray-400 hover:bg-gray-600 hover:text-white transition-colors"
              aria-label="Редактировать резюме"
            >
              <PencilIcon />
            </a>
          </div>
        ))}
      </div>
    </Card>
  );
};

export default ResumeSelector;