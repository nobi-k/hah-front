import React from 'react';
import Card from '../ui/Card';
import { CoverLetterConfig, CoverLetterMode } from '../../types';

interface CoverLetterSettingsProps {
  config: CoverLetterConfig;
  onConfigChange: (config: CoverLetterConfig) => void;
}

const DocumentTextIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
);

const modes: { id: CoverLetterMode; label: string }[] = [
  { id: 'ai', label: 'Генерация AI' },
  { id: 'template', label: 'Шаблон' },
  { id: 'none', label: 'Без письма' },
];

const CoverLetterSettings: React.FC<CoverLetterSettingsProps> = ({ config, onConfigChange }) => {
  const handleModeChange = (mode: CoverLetterMode) => {
    onConfigChange({ ...config, mode });
  };

  const handleTemplateChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onConfigChange({ ...config, template: e.target.value });
  };

  const handleAiSettingChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    onConfigChange({
      ...config,
      aiSettings: { ...config.aiSettings, [name]: value },
    });
  };

  return (
    <Card title="Настройка сопроводительных писем" icon={<DocumentTextIcon />}>
      <div className="space-y-4">
        {/* Mode Selector */}
        <div className="flex bg-gray-900/50 rounded-lg p-1 border border-gray-700">
          {modes.map(mode => (
            <button
              key={mode.id}
              onClick={() => handleModeChange(mode.id)}
              className={`w-full py-2 text-sm font-semibold rounded-md transition-colors duration-200 ${
                config.mode === mode.id
                  ? 'bg-primary-600 text-white'
                  : 'text-gray-300 hover:bg-gray-700'
              }`}
            >
              {mode.label}
            </button>
          ))}
        </div>

        {/* AI Settings */}
        {config.mode === 'ai' && (
          <div className="space-y-3 p-3 bg-gray-900/30 rounded-lg animate-fade-in">
            <div>
              <label htmlFor="tone" className="block text-sm font-medium text-gray-300 mb-1">Тон письма</label>
              <select id="tone" name="tone" value={config.aiSettings.tone} onChange={handleAiSettingChange} className="block w-full text-base bg-gray-700 border-gray-600 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md text-white">
                <option value="professional">Профессиональный</option>
                <option value="enthusiastic">Восторженный</option>
                <option value="formal">Формальный</option>
                <option value="friendly">Дружелюбный</option>
              </select>
            </div>
            <div>
              <label htmlFor="language" className="block text-sm font-medium text-gray-300 mb-1">Язык</label>
              <select id="language" name="language" value={config.aiSettings.language} onChange={handleAiSettingChange} className="block w-full text-base bg-gray-700 border-gray-600 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md text-white">
                <option value="russian">Русский</option>
                <option value="english">Английский</option>
              </select>
            </div>
          </div>
        )}

        {/* Template Textarea */}
        {config.mode === 'template' && (
          <div className="animate-fade-in">
            <label htmlFor="template" className="block text-sm font-medium text-gray-300 mb-1">Ваш шаблон</label>
            <textarea
              id="template"
              name="template"
              rows={8}
              value={config.template}
              onChange={handleTemplateChange}
              className="block w-full bg-gray-900/50 border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm text-white"
            />
          </div>
        )}

        {/* No Letter Info */}
        {config.mode === 'none' && (
            <div className="text-center p-4 bg-gray-900/30 rounded-lg text-sm text-gray-400 animate-fade-in">
                Отклики будут отправляться без сопроводительного письма.
            </div>
        )}
      </div>
      <style>{`
          @keyframes fade-in {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .animate-fade-in {
            animation: fade-in 0.3s ease-out forwards;
          }
        `}</style>
    </Card>
  );
};

export default CoverLetterSettings;