
import { User, Resume } from '../types';
import { mockResumes } from '../data/mockData';

// Mock user data including subscription details
const mockUser: User = {
  id: 'user123',
  name: 'Иван Петров',
  avatarUrl: 'https://picsum.photos/100/100',
  subscription: {
    status: 'active',
    planName: 'Pro',
    expiresAt: new Date(new Date().setDate(new Date().getDate() + 25)), // Expires in 25 days
  },
  paymentMethod: {
    type: 'card',
    last4: '4242',
    expires: '12/26',
  },
};


/**
 * Simulates a network request to log in the user.
 * @returns A promise that resolves with the user object.
 */
export const login = (): Promise<User> => {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve(mockUser);
        }, 1500); // Simulate 1.5 second network delay
    });
};

/**
 * Simulates fetching initial dashboard data like resumes.
 * @returns A promise that resolves with dashboard data.
 */
interface DashboardData {
    resumes: Resume[];
}
export const getDashboardData = (): Promise<DashboardData> => {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve({
                resumes: mockResumes,
            });
        }, 2000); // Simulate 2 second network delay
    });
};
