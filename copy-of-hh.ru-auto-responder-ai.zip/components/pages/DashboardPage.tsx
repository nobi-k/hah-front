import React, { useState, useEffect, useCallback } from 'react';
import Header from '../features/Header';
import ResumeSelector from '../features/ResumeSelector';
import FilterSettingsComponent from '../features/FilterSettings';
import CoverLetterSettings from '../features/CoverLetterSettings';
import AutoApplyControl from '../features/AutoApplyControl';
import StatsCards from '../features/StatsCards';
import ActivityLog from '../features/ActivityLog';
import ActivityChart from '../features/ActivityChart';
import SubscriptionModal from '../features/SubscriptionModal';
import { generateCoverLetter } from '../../services/geminiService';
import { generateMockVacancy } from '../../data/mockData';
import { getDashboardData } from '../../services/apiService';
import { Resume, FilterSettings, ApplicationLog, ChartData, User, CoverLetterConfig } from '../../types';
import LoadingSpinner from '../ui/LoadingSpinner';

interface DashboardPageProps {
  initialUser: User;
  onShowOnboarding: () => void;
  onReady: () => void;
}

const DashboardPage: React.FC<DashboardPageProps> = ({ initialUser, onShowOnboarding, onReady }) => {
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [selectedResumeIds, setSelectedResumeIds] = useState<string[]>([]);
  const [filters, setFilters] = useState<FilterSettings>({
    keywords: 'Product Manager, Frontend',
    excludeKeywords: 'стартап, gamedev',
    searchInDescription: true,
    salaryFrom: 200000,
    salaryNotImportant: false,
    experience: 'between3And6',
    employment: 'full',
    schedule: 'remote',
    applicationLimit: 50,
  });
  const [coverLetterConfig, setCoverLetterConfig] = useState<CoverLetterConfig>({
    mode: 'none',
    template: `Здравствуйте!

Меня заинтересовала ваша вакансия. Уверен, что мой опыт и навыки в [ваша область] будут полезны вашей команде.

Буду рад обсудить детали на собеседовании.

С уважением,
[Ваше имя]`,
    aiSettings: {
      tone: 'professional',
      language: 'russian',
    },
  });
  const [isApplying, setIsApplying] = useState<boolean>(false);
  const [logs, setLogs] = useState<ApplicationLog[]>([]);
  const [stats, setStats] = useState({ applications: 0, views: 0, invitations: 0 });
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        const data = await getDashboardData();
        setResumes(data.resumes);
      } catch (err) {
        setError('Не удалось загрузить данные. Попробуйте снова.');
        console.error(err);
      } finally {
        setIsLoading(false);
        onReady();
      }
    };
    fetchData();
  }, [onReady]);


  const handleApply = useCallback(async () => {
    if (selectedResumeIds.length === 0 || resumes.length === 0) return;

    const randomResumeId = selectedResumeIds[Math.floor(Math.random() * selectedResumeIds.length)];
    const resume = resumes.find(r => r.id === randomResumeId);
    if (!resume) return;

    const vacancy = generateMockVacancy();
    
    let coverLetter = '';
    if (coverLetterConfig.mode === 'template') {
      coverLetter = coverLetterConfig.template;
    } else if (coverLetterConfig.mode === 'ai') {
      coverLetter = await generateCoverLetter(resume, vacancy, coverLetterConfig.aiSettings);
    }

    const newLog: ApplicationLog = {
      id: `log${Date.now()}`,
      vacancy,
      resume,
      status: 'Applied',
      appliedAt: new Date(),
      coverLetter,
      coverLetterMode: coverLetterConfig.mode,
    };
    
    setLogs(prevLogs => [newLog, ...prevLogs].slice(0, 100)); // Keep max 100 logs
    setStats(prevStats => ({ ...prevStats, applications: prevStats.applications + 1 }));

    // Simulate views and invitations
    if (Math.random() < 0.2) {
      setTimeout(() => {
        setLogs(prev => prev.map(l => l.id === newLog.id ? {...l, status: 'Viewed'} : l));
        setStats(prev => ({...prev, views: prev.views + 1}));
      }, Math.random() * 5000 + 3000);
    }
     if (Math.random() < 0.05) {
      setTimeout(() => {
        setLogs(prev => prev.map(l => l.id === newLog.id ? {...l, status: 'Invitation'} : l));
        setStats(prev => ({...prev, invitations: prev.invitations + 1}));
      }, Math.random() * 10000 + 8000);
    }
  }, [selectedResumeIds, resumes, coverLetterConfig]);

  useEffect(() => {
    // FIX: Use ReturnType<typeof setInterval> for interval ID type to ensure browser compatibility, instead of NodeJS.Timeout.
    let intervalId: ReturnType<typeof setInterval> | null = null;
    if (isApplying) {
      handleApply(); // Apply immediately on start
      intervalId = setInterval(handleApply, 5000); // Apply every 5 seconds
    }
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [isApplying, handleApply]);

  const [chartData, setChartData] = useState<ChartData[]>([]);
    
  useEffect(() => {
      const today = new Date();
      const newChartData = Array.from({ length: 7 }).map((_, i) => {
          const date = new Date(today);
          date.setDate(today.getDate() - (6 - i));
          const dayLogs = logs.filter(log => {
              const logDate = new Date(log.appliedAt);
              return logDate.getFullYear() === date.getFullYear() &&
                     logDate.getMonth() === date.getMonth() &&
                     logDate.getDate() === date.getDate();
          });
          return {
              name: date.toLocaleDateString('ru-RU', { weekday: 'short' }),
              applications: dayLogs.length,
          };
      });
      setChartData(newChartData);
  }, [logs]);

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center">
        <LoadingSpinner large={true} />
        <p className="mt-4 text-lg text-gray-400">Загрузка данных...</p>
      </div>
    );
  }

  if (error) {
     return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center text-center">
        <div>
          <h2 className="text-2xl font-bold text-red-400">Ошибка</h2>
          <p className="mt-2 text-gray-400">{error}</p>
          <button 
            onClick={() => window.location.reload()}
            className="mt-6 px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700"
          >
            Перезагрузить страницу
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
    <div className="min-h-screen bg-gray-900">
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg animate-fade-in-down">
          {toastMessage}
        </div>
      )}
      <Header 
        user={initialUser} 
        onManageSubscription={() => setIsSubscriptionModalOpen(true)}
        onShowOnboarding={onShowOnboarding}
      />
      <main className="p-4 sm:p-6 lg:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          
          {/* Top Row: Stats */}
          <div id="onboarding-stats">
            <StatsCards stats={stats} />
          </div>

          {/* Second Row: Chart */}
          <ActivityChart data={chartData} />

          {/* Third Row: Settings & Controls */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Main Content (Left): Settings */}
            <div className="lg:col-span-2 space-y-8">
              <div id="onboarding-resumes">
                <ResumeSelector
                  resumes={resumes}
                  selectedIds={selectedResumeIds}
                  onSelectionChange={setSelectedResumeIds}
                />
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div id="onboarding-filters">
                  <FilterSettingsComponent filters={filters} onFilterChange={setFilters} />
                </div>
                <div id="onboarding-cover-letter">
                  <CoverLetterSettings config={coverLetterConfig} onConfigChange={setCoverLetterConfig} />
                </div>
              </div>
            </div>

            {/* Sidebar (Right): Control */}
            <div className="space-y-8">
              <div id="onboarding-control">
                <AutoApplyControl
                  isApplying={isApplying}
                  onToggle={() => setIsApplying(!isApplying)}
                  isDisabled={selectedResumeIds.length === 0}
                  onDisabledClick={() => showToast('Пожалуйста, сначала выберите резюме.')}
                />
              </div>
            </div>

          </div>

          {/* Bottom Row: Activity Log */}
          <div id="onboarding-log">
            <ActivityLog logs={logs} />
          </div>
        </div>
      </main>
    </div>
    <SubscriptionModal
        isOpen={isSubscriptionModalOpen}
        onClose={() => setIsSubscriptionModalOpen(false)}
        user={initialUser}
      />
      <style>{`
        @keyframes fade-in-down {
          from { opacity: 0; transform: translateY(-20px) translateX(-50%); }
          to { opacity: 1; transform: translateY(0) translateX(-50%); }
        }
        .animate-fade-in-down {
          animation: fade-in-down 0.5s ease-out forwards;
        }
      `}</style>
    </>
  );
};

export default DashboardPage;