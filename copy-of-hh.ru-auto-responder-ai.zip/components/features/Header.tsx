import React, { useState, useEffect, useRef } from 'react';
import { User } from '../../types';

interface HeaderProps {
  user: User;
  onManageSubscription: () => void;
  onShowOnboarding: () => void;
}

const getDaysRemaining = (subscription: User['subscription']) => {
    if (subscription.status !== 'active') return 0;
    const today = new Date();
    const expiryDate = new Date(subscription.expiresAt);
    const diffTime = expiryDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
};

const getDaysRemainingText = (days: number) => {
    const lastDigit = days % 10;
    const lastTwoDigits = days % 100;
    if (lastTwoDigits >= 11 && lastTwoDigits <= 19) return 'дней';
    if (lastDigit === 1) return 'день';
    if (lastDigit >= 2 && lastDigit <= 4) return 'дня';
    return 'дней';
};

const Header: React.FC<HeaderProps> = ({ user, onManageSubscription, onShowOnboarding }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const daysRemaining = getDaysRemaining(user.subscription);
  const daysText = getDaysRemainingText(daysRemaining);

  return (
    <header className="bg-gray-800/50 backdrop-blur-sm border-b border-gray-700 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 text-white text-xl font-bold">
              HH Auto-Responder <span className="text-primary-400">AI</span>
            </div>
          </div>
          <div className="relative" ref={menuRef} id="onboarding-profile-menu">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-700/50 transition-colors">
              {user.subscription.status === 'active' && (
                <span className="bg-primary-500 text-white text-xs font-bold px-2.5 py-0.5 rounded-full">
                  {user.subscription.planName.toUpperCase()}
                </span>
              )}
              <span className="text-sm text-gray-300 hidden sm:block">{user.name}</span>
              <img 
                className="h-8 w-8 rounded-full ring-2 ring-primary-500"
                src={user.avatarUrl} 
                alt="User Avatar" 
              />
              <svg className={`w-5 h-5 text-gray-400 transition-transform ${isMenuOpen ? 'rotate-180' : ''}`} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
            {isMenuOpen && (
              <div className="absolute right-0 mt-2 w-72 bg-gray-800 border border-gray-700 rounded-lg shadow-2xl origin-top-right animate-fade-in-down">
                <div className="p-4 border-b border-gray-700">
                  <div className="flex items-center space-x-3">
                     <img 
                      className="h-12 w-12 rounded-full"
                      src={user.avatarUrl} 
                      alt="User Avatar" 
                    />
                    <div>
                      <h4 className="font-semibold text-white">{user.name}</h4>
                      <p className="text-sm text-gray-400">{user.subscription.planName} Plan</p>
                    </div>
                  </div>
                   {user.subscription.status === 'active' && (
                    <div className="mt-4 text-center p-3 bg-gray-900/50 rounded-lg">
                      <p className="text-2xl font-bold text-white">{daysRemaining}</p>
                      <p className="text-sm text-gray-400">{daysText} подписки</p>
                    </div>
                  )}
                </div>
                <div className="p-2 space-y-1">
                   <button onClick={() => { onManageSubscription(); setIsMenuOpen(false); }} className="w-full text-left px-3 py-2 text-sm rounded-md text-gray-300 hover:bg-gray-700/70 hover:text-white transition-colors">
                      Управлять подпиской
                    </button>
                    <button onClick={() => { onShowOnboarding(); setIsMenuOpen(false); }} className="w-full text-left px-3 py-2 text-sm rounded-md text-gray-300 hover:bg-gray-700/70 hover:text-white transition-colors">
                      Повторить обучение
                    </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      <style>{`
        @keyframes fade-in-down {
          from { opacity: 0; transform: translateY(-10px) scale(0.95); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
        .animate-fade-in-down {
          animation: fade-in-down 0.2s ease-out forwards;
        }
      `}</style>
    </header>
  );
};

export default Header;