
// FIX: Import GoogleGenAI from @google/genai as per guidelines.
import { GoogleGenAI } from "@google/genai";
import { Resume, Vacancy, AiSettings } from '../types';

// FIX: Initialize GoogleGenAI client with API key from environment variables.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateCoverLetter = async (
  resume: Resume,
  vacancy: Vacancy,
  aiSettings: AiSettings
): Promise<string> => {
  console.log(`Generating AI cover letter for ${vacancy.title} using resume ${resume.title}`);

  const toneMapping = {
    professional: 'professional and confident',
    enthusiastic: 'enthusiastic and passionate',
    formal: 'strictly formal and respectful',
    friendly: 'friendly and approachable',
  };

  const languageMapping = {
      russian: 'Russian',
      english: 'English',
  };

  const prompt = `
    Generate a professional and concise cover letter for the position of "${vacancy.title}" at ${vacancy.company}.
    The candidate is applying with their resume titled "${resume.title}".
    Highlight the candidate's suitability for the role based on the job title and company.
    The tone should be ${toneMapping[aiSettings.tone]}.
    Keep it to 3 paragraphs.
    The response must be in ${languageMapping[aiSettings.language]}.
  `;
  
  // FIX: Replaced mocked implementation with a real Gemini API call, using the correct model and error handling.
  try {
    const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
    // FIX: Extract text from the response using the .text property as per guidelines.
    return response.text;
  } catch (error) {
    console.error("Error generating cover letter with Gemini API:", error);
    // Fallback to an error message if the API call fails.
    return `Error: Could not generate cover letter. Please check API key and connection.`;
  }
};