
import { Resume, Vacancy } from '../types';

export const mockResumes: Resume[] = [
  {
    id: 'res1',
    title: 'Product Manager (SaaS & Fintech)',
    url: '#',
    updatedAt: '2024-07-20T10:00:00Z',
  },
  {
    id: 'res2',
    title: 'Senior Frontend Developer (React, TypeScript)',
    url: '#',
    updatedAt: '2024-07-21T11:30:00Z',
  },
  {
    id: 'res3',
    title: 'Digital Marketing Director',
    url: '#',
    updatedAt: '2024-07-19T09:00:00Z',
  },
];

const vacancyTitles = [
  'Senior Product Manager', 'Head of Digital Marketing', 'Lead Frontend Engineer', 'IT Project Manager', 
  'Chief Technology Officer (CTO)', 'Data Scientist', 'UX/UI Design Lead', 'DevOps Engineer', 'Business Analyst'
];
const companies = ['TechCorp', 'Innovate LLC', 'Digital Solutions', 'Future Systems', 'SaaS Innovations', 'Fintech United'];
const locations = ['Москва', 'Санкт-Петербург', 'Удаленно', 'Новосибирск'];

export const generateMockVacancy = (): Vacancy => {
  const id = `vac${Math.random().toString(36).substring(7)}`;
  const title = vacancyTitles[Math.floor(Math.random() * vacancyTitles.length)];
  const company = companies[Math.floor(Math.random() * companies.length)];
  const salary = `${150000 + Math.floor(Math.random() * 20) * 10000} - ${300000 + Math.floor(Math.random() * 30) * 10000} RUB`;
  const location = locations[Math.floor(Math.random() * locations.length)];
  return { id, title, company, salary, url: '#', location };
};
