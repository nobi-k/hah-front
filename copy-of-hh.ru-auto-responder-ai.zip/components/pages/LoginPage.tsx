
import React from 'react';
import LoadingSpinner from '../ui/LoadingSpinner';

interface LoginPageProps {
  onLogin: () => void;
  isLoading: boolean;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin, isLoading }) => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900">
      <div className="w-full max-w-md p-8 space-y-8 bg-gray-800 rounded-2xl shadow-2xl text-center">
        <div>
          <h2 className="text-4xl font-extrabold text-white">
            HH Auto-Responder AI
          </h2>
          <p className="mt-2 text-gray-400">
            Автоматизируйте поиск работы с помощью ИИ.
          </p>
        </div>
        <button
          onClick={onLogin}
          disabled={isLoading}
          className="w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-primary-500 transition-transform transform hover:scale-105 disabled:bg-primary-800 disabled:scale-100 disabled:cursor-wait"
        >
          {isLoading ? (
            <LoadingSpinner />
          ) : (
            <>
              <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path fillRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1.5-6.5l3-3-1.06-1.06-1.94 1.94-1.94-1.94L8.5 8.5l3 3zm-1.5 2h3V16h-3v-2.5z" clipRule="evenodd" />
              </svg>
              Войти через hh.ru
            </>
          )}
        </button>
        <p className="text-xs text-gray-500">
          Нажимая кнопку, вы симулируете безопасный вход через OAuth hh.ru.
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
