
import React, { useState } from 'react';
import Modal from '../ui/Modal';
import { User } from '../../types';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
}

const plans = [
    { name: 'Basic', price: '499₽/мес', features: ['50 автооткликов/день', 'Базовые фильтры'] },
    { name: 'Pro', price: '999₽/мес', features: ['200 автооткликов/день', 'Все фильтры', 'AI письма'] },
    { name: 'Business', price: '1999₽/мес', features: ['Безлимитные отклики', 'Приоритетная поддержка'] },
];

const SubscriptionModal: React.FC<SubscriptionModalProps> = ({ isOpen, onClose, user }) => {
  const [currentPlan, setCurrentPlan] = useState(user.subscription.planName);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Управление подпиской"
    >
        <div className="space-y-6 text-gray-300">
            {/* --- Plan Selection --- */}
            <div>
                <h3 className="text-lg font-semibold text-white mb-3">Сменить тарифный план</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {plans.map(plan => (
                        <div 
                            key={plan.name}
                            onClick={() => setCurrentPlan(plan.name)}
                            className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                                currentPlan === plan.name ? 'border-primary-500 bg-primary-900/40' : 'border-gray-600 hover:border-gray-500 bg-gray-700/50'
                            }`}
                        >
                            <h4 className="font-bold text-white">{plan.name}</h4>
                            <p className="text-xl font-extrabold text-white my-2">{plan.price}</p>
                            <ul className="text-xs space-y-1 text-gray-400">
                                {plan.features.map(feature => <li key={feature}>- {feature}</li>)}
                            </ul>
                        </div>
                    ))}
                </div>
            </div>

            {/* --- Payment Method --- */}
            <div>
                <h3 className="text-lg font-semibold text-white mb-3">Способ оплаты</h3>
                <div className="flex items-center justify-between p-4 bg-gray-700/50 rounded-lg border border-gray-600">
                    <div className="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-400 mr-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                        </svg>
                        <div>
                            <p className="font-semibold text-white">Карта **** {user.paymentMethod.last4}</p>
                            <p className="text-sm text-gray-400">Истекает: {user.paymentMethod.expires}</p>
                        </div>
                    </div>
                    <button className="text-sm font-medium text-primary-400 hover:text-primary-300">
                        Изменить
                    </button>
                </div>
            </div>
            
            <div className="border-t border-gray-700 pt-6 space-y-4">
                 <button
                    className="w-full bg-primary-600 hover:bg-primary-700 text-white font-bold py-2.5 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-primary-500"
                    >
                    Сохранить изменения
                </button>
                <button
                    className="w-full bg-transparent hover:bg-red-500/20 text-red-400 hover:text-red-300 font-bold py-2.5 px-4 rounded-lg transition-colors border border-red-500/50 hover:border-red-500/80"
                    >
                    Отменить подписку
                </button>
            </div>

        </div>
    </Modal>
  );
};

export default SubscriptionModal;
