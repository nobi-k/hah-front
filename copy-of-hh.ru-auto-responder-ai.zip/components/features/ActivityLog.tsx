
import React, { useState } from 'react';
import Card from '../ui/Card';
import Modal from '../ui/Modal';
import { ApplicationLog, CoverLetterMode } from '../../types';

interface ActivityLogProps {
  logs: ApplicationLog[];
}

const statusStyles: { [key: string]: string } = {
  Applied: 'bg-blue-500/20 text-blue-300',
  Viewed: 'bg-purple-500/20 text-purple-300',
  Invitation: 'bg-green-500/20 text-green-300',
};

const coverLetterModeStyles: { [key in CoverLetterMode]: string } = {
  ai: 'bg-indigo-500/20 text-indigo-300',
  template: 'bg-yellow-500/20 text-yellow-300',
  none: 'bg-gray-500/20 text-gray-400',
};

const coverLetterModeText: { [key in CoverLetterMode]: string } = {
    ai: 'AI Сгенерировано',
    template: 'Шаблон',
    none: 'Без письма',
};

const ListBulletIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
    </svg>
);


const ActivityLog: React.FC<ActivityLogProps> = ({ logs }) => {
  const [selectedLog, setSelectedLog] = useState<ApplicationLog | null>(null);

  return (
    <>
      <Card title="Журнал активности" icon={<ListBulletIcon />}>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-700">
            <thead className="bg-gray-800">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Вакансия</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Резюме</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Письмо</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Статус</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Время</th>
                <th scope="col" className="relative px-6 py-3"><span className="sr-only">Действия</span></th>
              </tr>
            </thead>
            <tbody className="bg-gray-800/50 divide-y divide-gray-700">
              {logs.map(log => (
                <tr key={log.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-white">{log.vacancy.title}</div>
                    <div className="text-sm text-gray-400">{log.vacancy.company}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{log.resume.title}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${coverLetterModeStyles[log.coverLetterMode]}`}>
                      {coverLetterModeText[log.coverLetterMode]}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusStyles[log.status]}`}>
                      {log.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">{log.appliedAt.toLocaleTimeString('ru-RU')}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    {log.coverLetter && (
                      <button onClick={() => setSelectedLog(log)} className="text-primary-400 hover:text-primary-300">
                        Посмотреть письмо
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Modal
        isOpen={!!selectedLog}
        onClose={() => setSelectedLog(null)}
        title={`Сопроводительное письмо для: ${selectedLog?.vacancy.title}`}
      >
        <div className="text-gray-300 whitespace-pre-wrap font-mono bg-gray-900 p-4 rounded-md">
          {selectedLog?.coverLetter || 'Сопроводительное письмо не отправлялось.'}
        </div>
      </Modal>
    </>
  );
};

export default ActivityLog;