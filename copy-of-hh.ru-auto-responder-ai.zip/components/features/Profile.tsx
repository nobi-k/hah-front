import React from 'react';
import Card from '../ui/Card';
import { User } from '../../types';

interface ProfileProps {
  user: User;
  onManageSubscription: () => void;
  onShowOnboarding: () => void;
}

const UserCircleIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);


const Profile: React.FC<ProfileProps> = ({ user, onManageSubscription, onShowOnboarding }) => {
  const { subscription } = user;

  const getDaysRemaining = () => {
    if (subscription.status !== 'active') return 0;
    const today = new Date();
    const expiryDate = new Date(subscription.expiresAt);
    const diffTime = expiryDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  const getDaysRemainingText = (days: number) => {
    const lastDigit = days % 10;
    const lastTwoDigits = days % 100;

    if (lastTwoDigits >= 11 && lastTwoDigits <= 19) {
        return 'дней осталось';
    }
    if (lastDigit === 1) {
        return 'день остался';
    }
    if (lastDigit >= 2 && lastDigit <= 4) {
        return 'дня осталось';
    }
    return 'дней осталось';
  };

  const daysRemaining = getDaysRemaining();
  const daysRemainingText = getDaysRemainingText(daysRemaining);
  const expiryDateString = new Date(subscription.expiresAt).toLocaleDateString('ru-RU');

  return (
    <Card title="Профиль и подписка" icon={<UserCircleIcon />}>
      <div className="space-y-4">
        <div className="flex items-center space-x-4">
          <img src={user.avatarUrl} alt="User Avatar" className="h-16 w-16 rounded-full" />
          <div>
            <h4 className="text-xl font-bold text-white">{user.name}</h4>
            <p className="text-sm text-gray-400">Тариф: <span className="font-semibold text-primary-400">{subscription.planName}</span></p>
          </div>
        </div>

        <div className="p-4 bg-gray-900/50 rounded-lg">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-gray-300">Статус подписки</span>
            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
              subscription.status === 'active' ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'
            }`}>
              {subscription.status === 'active' ? 'Активна' : 'Неактивна'}
            </span>
          </div>
          {subscription.status === 'active' && (
            <div className="mt-3 text-center">
                <p className="text-3xl font-bold text-white">{daysRemaining}</p>
                <p className="text-sm text-gray-400">
                   {daysRemainingText}
                </p>
                <p className="text-xs text-gray-500 mt-1">Истекает {expiryDateString}</p>
            </div>
          )}
        </div>
        
        <div className="space-y-2 pt-2">
          <button
            onClick={onManageSubscription}
            className="w-full bg-primary-600 hover:bg-primary-700 text-white font-bold py-2 px-4 rounded-lg transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-primary-500"
          >
            Управлять подпиской
          </button>
          <button
            onClick={onShowOnboarding}
            className="w-full bg-gray-700 hover:bg-gray-600 text-gray-300 font-medium py-2 px-4 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-gray-500"
          >
            Повторить обучение
          </button>
        </div>
      </div>
    </Card>
  );
};

export default Profile;