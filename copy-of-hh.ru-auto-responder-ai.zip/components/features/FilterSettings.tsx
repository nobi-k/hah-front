import React from 'react';
import Card from '../ui/Card';
import { FilterSettings } from '../../types';

interface FilterSettingsProps {
  filters: FilterSettings;
  onFilterChange: (filters: FilterSettings) => void;
}

const SlidersIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 16v-2m0-8v-2m-6 2H4m16 0h-2m-6 6h-2m6 0h2m-8-6H4m16 0h-2M8 6H4m16 0h-2" />
    </svg>
);


const FilterSettingsComponent: React.FC<FilterSettingsProps> = ({ filters, onFilterChange }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        onFilterChange({ ...filters, [name]: checked });
    } else {
       // For number and range inputs, convert value to a number
        if (type === 'number' || type === 'range') {
            const numericValue = parseFloat(value);
            onFilterChange({ ...filters, [name]: isNaN(numericValue) ? 0 : numericValue });
        } else {
            onFilterChange({ ...filters, [name]: value });
        }
    }
  };

  return (
    <Card title="Фильтры поиска" icon={<SlidersIcon />}>
      <form className="space-y-4">
        <div>
          <label htmlFor="keywords" className="block text-sm font-medium text-gray-300">Ключевые слова</label>
          <input
            type="text"
            name="keywords"
            id="keywords"
            value={filters.keywords}
            onChange={handleChange}
            placeholder="Например: Product Manager, React"
            className="mt-1 block w-full bg-gray-900/50 border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm text-white"
          />
        </div>

        <div>
          <label htmlFor="excludeKeywords" className="block text-sm font-medium text-gray-300">Минус-слова</label>
          <input
            type="text"
            name="excludeKeywords"
            id="excludeKeywords"
            value={filters.excludeKeywords}
            onChange={handleChange}
            placeholder="Например: стартап, gamedev"
            className="mt-1 block w-full bg-gray-900/50 border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm text-white"
          />
        </div>

        <div className="flex items-center">
            <input
                id="searchInDescription"
                name="searchInDescription"
                type="checkbox"
                checked={filters.searchInDescription}
                onChange={handleChange}
                className="h-4 w-4 text-primary-600 bg-gray-900 border-gray-600 rounded focus:ring-primary-500"
            />
            <label htmlFor="searchInDescription" className="ml-2 block text-sm text-gray-300">
                Искать в описании
            </label>
        </div>

        <div>
          <label htmlFor="salaryFrom" className="block text-sm font-medium text-gray-300">Зарплата от (RUB)</label>
          <input
            type="number"
            name="salaryFrom"
            id="salaryFrom"
            value={filters.salaryFrom}
            onChange={handleChange}
            disabled={filters.salaryNotImportant}
            className="mt-1 block w-full bg-gray-900/50 border-gray-600 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm text-white disabled:opacity-50 disabled:cursor-not-allowed"
          />
        </div>
        
        <div className="flex items-center">
            <input
                id="salaryNotImportant"
                name="salaryNotImportant"
                type="checkbox"
                checked={filters.salaryNotImportant}
                onChange={handleChange}
                className="h-4 w-4 text-primary-600 bg-gray-900 border-gray-600 rounded focus:ring-primary-500"
            />
            <label htmlFor="salaryNotImportant" className="ml-2 block text-sm text-gray-300">
                Не имеет значения
            </label>
        </div>

        <div>
          <label htmlFor="applicationLimit" className="block text-sm font-medium text-gray-300">Дневной лимит откликов</label>
          <div className="flex items-center space-x-3 mt-1">
            <input
              type="range"
              min="5"
              max="200"
              name="applicationLimit"
              id="applicationLimit"
              value={filters.applicationLimit}
              onChange={handleChange}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-primary-500"
            />
            <input
              type="number"
              min="5"
              max="200"
              name="applicationLimit"
              value={filters.applicationLimit}
              onChange={handleChange}
              className="w-20 bg-gray-900/50 border-gray-600 rounded-md shadow-sm text-center focus:ring-primary-500 focus:border-primary-500 sm:text-sm text-white"
            />
          </div>
        </div>

        <div>
          <label htmlFor="experience" className="block text-sm font-medium text-gray-300">Опыт работы</label>
          <select id="experience" name="experience" value={filters.experience} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-gray-900/50 border-gray-600 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md text-white">
            <option value="noExperience">Нет опыта</option>
            <option value="between1And3">От 1 года до 3 лет</option>
            <option value="between3And6">От 3 до 6 лет</option>
            <option value="moreThan6">Более 6 лет</option>
          </select>
        </div>
        <div>
          <label htmlFor="schedule" className="block text-sm font-medium text-gray-300">График работы</label>
          <select id="schedule" name="schedule" value={filters.schedule} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-gray-900/50 border-gray-600 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md text-white">
            <option value="fullDay">Полный день</option>
            <option value="shift">Сменный график</option>
            <option value="flexible">Гибкий график</option>
            <option value="remote">Удаленная работа</option>
          </select>
        </div>
      </form>
    </Card>
  );
};

export default FilterSettingsComponent;