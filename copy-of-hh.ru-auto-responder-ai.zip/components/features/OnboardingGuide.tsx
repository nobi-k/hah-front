import React, { useState, useLayoutEffect } from 'react';

interface OnboardingStep {
  target: string;
  title: string;
  content: string;
  position: 'top' | 'bottom' | 'left' | 'right';
}

const steps: OnboardingStep[] = [
  {
    target: '#onboarding-stats',
    title: 'Шаг 1: Ваша статистика',
    content: 'Следите за результатами здесь: отклики, просмотры и приглашения.',
    position: 'bottom',
  },
  {
    target: '#onboarding-profile-menu',
    title: 'Шаг 2: Ваш профиль',
    content: 'Здесь находится ваш профиль и управление подпиской. Нажмите, чтобы открыть меню.',
    position: 'bottom',
  },
  {
    target: '#onboarding-resumes',
    title: 'Шаг 3: Выбор резюме',
    content: 'Начните с выбора одного или нескольких резюме для откликов.',
    position: 'right',
  },
  {
    target: '#onboarding-filters',
    title: 'Шаг 4: Настройка фильтров',
    content: 'Задайте параметры поиска: ключевые слова, зарплата и другие критерии.',
    position: 'top',
  },
  {
    target: '#onboarding-cover-letter',
    title: 'Шаг 5: Сопроводительное письмо',
    content: 'Выберите режим работы с сопроводительными письмами: AI, шаблон или без письма.',
    position: 'top',
  },
  {
    target: '#onboarding-control',
    title: 'Шаг 6: Запуск системы',
    content: 'Когда всё будет настроено, нажмите эту кнопку для старта.',
    position: 'left',
  },
  {
    target: '#onboarding-log',
    title: 'Шаг 7: Журнал активности',
    content: 'Внизу страницы вы найдете детальный лог всех ваших действий.',
    position: 'top',
  },
];

const getTooltipPosition = (rect: DOMRect, position: OnboardingStep['position']): React.CSSProperties => {
  const tooltipOffset = 16; // space between highlight and tooltip
  switch (position) {
    case 'top':
      return { bottom: `calc(100% + ${tooltipOffset}px)`, left: '50%', transform: 'translateX(-50%)' };
    case 'bottom':
      return { top: `calc(100% + ${tooltipOffset}px)`, left: '50%', transform: 'translateX(-50%)' };
    case 'left':
      return { right: `calc(100% + ${tooltipOffset}px)`, top: '50%', transform: 'translateY(-50%)' };
    case 'right':
      return { left: `calc(100% + ${tooltipOffset}px)`, top: '50%', transform: 'translateY(-50%)' };
    default:
      return {};
  }
};

const OnboardingGuide: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [stepIndex, setStepIndex] = useState(0);
  const [styles, setStyles] = useState<{ highlight: React.CSSProperties; tooltip: React.CSSProperties }>({ highlight: { opacity: 0 }, tooltip: {} });
  const currentStep = steps[stepIndex];

  useLayoutEffect(() => {
    const targetElement = document.querySelector(currentStep.target) as HTMLElement;
    if (targetElement) {
      // FIX: Changed scroll behavior to 'auto' for instant scrolling to prevent positioning race conditions.
      targetElement.scrollIntoView({ behavior: 'auto', block: 'center', inline: 'center' });

      const handlePositioning = () => {
        const rect = targetElement.getBoundingClientRect();
        const highlightStyle: React.CSSProperties = {
          width: rect.width + 16,
          height: rect.height + 16,
          top: rect.top - 8,
          left: rect.left - 8,
          boxShadow: '0 0 0 9999px rgba(17, 24, 39, 0.8)',
          opacity: 1,
        };
        const tooltipStyle = getTooltipPosition(rect, currentStep.position);
        setStyles({ highlight: highlightStyle, tooltip: tooltipStyle });
      };

      // FIX: Reduced timeout as scrolling is now instantaneous. This small delay ensures the browser has processed the scroll.
      const timeoutId = setTimeout(handlePositioning, 50);
      window.addEventListener('resize', handlePositioning);

      return () => {
        clearTimeout(timeoutId);
        window.removeEventListener('resize', handlePositioning);
      };
    }
  }, [stepIndex, currentStep]);

  const goToNext = () => setStepIndex(prev => Math.min(prev + 1, steps.length - 1));
  const goToPrev = () => setStepIndex(prev => Math.max(prev - 1, 0));
  const finishOnboarding = () => onComplete();

  return (
    <div className="fixed inset-0 z-[100]" aria-live="polite">
      <div
        className="absolute rounded-lg border-2 border-primary-500 border-dashed transition-all duration-500 ease-in-out"
        style={styles.highlight}
      >
        <div
          style={styles.tooltip}
          className="absolute w-80 bg-gray-800 border border-gray-700 rounded-lg shadow-2xl p-5 text-gray-200 animate-fade-in"
        >
          <h3 className="text-xl font-bold text-primary-400 mb-2">{currentStep.title}</h3>
          <p className="text-gray-300 mb-4">{currentStep.content}</p>
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-gray-400">{stepIndex + 1} / {steps.length}</span>
            <div className="flex items-center space-x-2">
              {stepIndex > 0 && (
                <button onClick={goToPrev} className="px-3 py-1 text-sm rounded-md hover:bg-gray-700 transition-colors">Назад</button>
              )}
              {stepIndex < steps.length - 1 ? (
                <button onClick={goToNext} className="px-4 py-2 text-sm font-semibold text-white bg-primary-600 rounded-md hover:bg-primary-700 transition-colors">Далее</button>
              ) : (
                <button onClick={finishOnboarding} className="px-4 py-2 text-sm font-semibold text-white bg-green-600 rounded-md hover:bg-green-700 transition-colors">Завершить</button>
              )}
            </div>
          </div>
           <button onClick={finishOnboarding} className="absolute top-2 right-2 text-gray-500 hover:text-white transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
        </div>
      </div>
       <style>{`
          @keyframes fade-in {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
          }
          .animate-fade-in {
            animation: fade-in 0.3s ease-out forwards;
          }
        `}</style>
    </div>
  );
};

export default OnboardingGuide;